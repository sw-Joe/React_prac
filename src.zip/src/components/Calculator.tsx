import { useState } from "react";
import CalculatorButton from "./CalculatorButton";

export default function Calculator() {
  const [calcState, setCalcState] = useState<CalcState> ({
    currentNum: "0",
    prevNum: "",
    operator: null,
    isNewNum: true
  })

  const handleClear = (e: React.MouseEvent<HTMLInputElement, MouseEvent>) => {
    console.debug(e.currentTarget.value);
    setCalcState((calculatorState) => ({
      ...calculatorState,
      currentNum: calculatorState.isNewNum? value : calculatorState.currentNum + value,
      isNewNum: false,
    }));
  }
  const handleOperator = (e: React.MouseEvent<HTMLInputElement, MouseEvent>) => {
    console.debug(e.currentTarget.value);
    const operator = e.currentTarget.value;
    setCalcState((calculatorState) => {
      const current = parseFloat(calculatorState.currentNum);
      if (operator === "=") return { ...calculatorState, isNewNum: true };
      return {
        currentNum: "",
        prevNum: current.toString(),
        operator: operator,
        isNewNum: true,
      }
    })
  }
  const handleNum = (e: React.MouseEvent<HTMLInputElement, MouseEvent>) => {}
  const handleDot = (e: React.MouseEvent<HTMLInputElement, MouseEvent>) => {}

  const btnCfgs : btnCfgs[] = [
    {value: "C", className: "calc-clear", onClick: handleClear},
    {value: "/", className: "calc-operator", onClick: handleOperator},
    {value: "1", className: "calc-num", onClick: handleNum},
    {value: "2", className: "calc-num", onClick: handleNum},
    {value: "3", className: "calc-num", onClick: handleNum},
    {value: "*", className: "calc-operator", onClick: handleOperator},
    {value: "4", className: "calc-num", onClick: handleNum},
    {value: "5", className: "calc-num", onClick: handleNum},
    {value: "6", className: "calc-num", onClick: handleNum},
    {value: "+", className: "calc-operator", onClick: handleOperator},
    {value: "7", className: "calc-num", onClick: handleNum},
    {value: "8", className: "calc-num", onClick: handleNum},
    {value: "9", className: "calc-num", onClick: handleNum},
    {value: "-", className: "calc-operator", onClick: handleOperator},
    {value: ".", className: "calc-dot", onClick: handleDot},
    {value: "0", className: "calc-num", onClick: handleNum},
    {value: "=", className: "calc-result", onClick: handleOperator},
  ];

  return (
    <>
      <div className="bg-[#1f1f1f] flex items-center justify-center h-screen">
        <article className="w-[282px] border border-[#333] bg-[#ccc] p-1">
          <form className="grid grid-cols-[repeat(4, 65px)] auto-rows-[65px] gap-1" name="forms">
            <input type="text" className="calc-input" name="output" readOnly />
            {btnCfgs.map((btn) => (
              <CalculatorButton key={btn.value} {...btn} />
            ))}
          </form>
        </article>
      </div>
    </>
  );
}